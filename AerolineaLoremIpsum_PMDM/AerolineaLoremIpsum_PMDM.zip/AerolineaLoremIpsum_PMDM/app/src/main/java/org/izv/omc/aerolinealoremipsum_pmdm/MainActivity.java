package org.izv.omc.aerolinealoremipsum_pmdm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    protected TextView etOrigen, etDestino;
    protected CheckBox cbMovilidadReducida, cbPrimeraClase, cbVentanilla, cbDesayuno, cbAlmuerzo, cbCena;
    protected Switch swMascota, swSeguro;

    protected Switch swPreferente;
    protected Button btComprar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        initialize();
    }

    private void initialize() {
        etOrigen = findViewById(R.id.etOrigen);
        etDestino = findViewById(R.id.etDestino);
        cbMovilidadReducida = findViewById(R.id.cbMovilidadReducida);
        cbPrimeraClase = findViewById(R.id.cbPrimeraClase);
        cbVentanilla = findViewById(R.id.cbVentanilla);
        cbDesayuno = findViewById(R.id.cbDesayuno);
        cbAlmuerzo = findViewById(R.id.cbAlmuerzo);
        cbCena = findViewById(R.id.cbCena);
        swMascota=findViewById(R.id.swMascota);
        swSeguro=findViewById(R.id.swSeguro);

        swPreferente = findViewById(R.id.swPreferente);
        btComprar = findViewById(R.id.btComprar);

        Context context = getApplicationContext();
        CharSequence text = "Se cobrar un coste adicional";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);

        swPreferente.setOnClickListener((View view)->{
            if (swPreferente.isChecked()){
                toast.show();
            }
        });

        //Dialogo
        AlertDialog dialogo = new AlertDialog
                .Builder(MainActivity.this) // NombreDeTuActividad.this, o getActivity() si es dentro de un fragmento
                .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Hicieron click en el botón positivo, así que la acción está confirmada
                        Intent intent = new Intent(getApplicationContext(), SecondActivity.class);

                        Bundle bundle = new Bundle();
                        pasarDatos(bundle);

                        intent.putExtras(bundle);

                        startActivity(intent);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Hicieron click en el botón negativo, no confirmaron
                        // Simplemente descartamos el diálogo
                        dialog.dismiss();
                        Snackbar.make(getWindow().getDecorView().getRootView(), "No hay conexion a internet.", Snackbar.LENGTH_LONG)
                                .show();
                    }
                })
                .setTitle("Confirmar") // El título
                .setMessage("¿Deseas Seguir con la compra?") // El mensaje
                .create();// No olvides llamar a Create, ¡pues eso crea el AlertDialog!

        btComprar.setOnClickListener((View view) -> {
            dialogo.show();
        });

    }

    private Bundle pasarDatos(Bundle bundle) {
        bundle.putString("etOrigen", etOrigen.getText().toString().toLowerCase());
        bundle.putString("etDestino", etDestino.getText().toString().toLowerCase());
        bundle.putString("cbMovilidadReducida", String.valueOf(cbMovilidadReducida.isChecked()));
        bundle.putString("cbPrimeraClase", String.valueOf(cbPrimeraClase.isChecked()));
        bundle.putString("swMascota", String.valueOf(swMascota.isActivated()));
        bundle.putString("cbDesayuno", String.valueOf(cbDesayuno.isChecked()));
        bundle.putString("cbAlmuerzo", String.valueOf(cbAlmuerzo.isChecked()));
        bundle.putString("cbCena", String.valueOf(cbCena.isChecked()));
        bundle.putString("swSeguro", String.valueOf(swSeguro.isActivated()));
        bundle.putString("swPreferente", String.valueOf(swPreferente.isActivated()));


        return bundle;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}