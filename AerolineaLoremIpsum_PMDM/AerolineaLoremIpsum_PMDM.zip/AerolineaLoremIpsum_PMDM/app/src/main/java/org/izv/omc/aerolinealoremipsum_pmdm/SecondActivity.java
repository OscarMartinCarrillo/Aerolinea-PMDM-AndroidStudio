package org.izv.omc.aerolinealoremipsum_pmdm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.math.BigInteger;
import java.util.Random;

public class SecondActivity extends AppCompatActivity {
    protected String etOrigen, etDestino, cbMovilidadReducida, cbPrimeraClase, swMascota, cbVentanilla, cbDesayuno, cbAlmuerzo, cbCena, swSeguro, swPreferente;
    protected TextView tvResult;
    protected Button btContinuar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Bundle bundle = getIntent().getExtras();

        getDatos(bundle);

        initialize();

    }

    private void initialize() {
        tvResult = findViewById(R.id.tvResult);
        btContinuar = findViewById(R.id.btContinuar);

        int localizacion=pasarNumero(etOrigen)+pasarNumero(etDestino);
        Random generator = new Random(localizacion);
        double random = generator.nextDouble()*1000;
        random = Math.round(random*100.0)/100.0;
        double total=calcularTotal(random);
        total = Math.round(total*100.0)/100.0;
        tvResult.setText(String.valueOf(total));

        Intent intent = new Intent(getApplicationContext(), ThirdActivity.class);

        Bundle bundle = new Bundle();
        pasarDatos(bundle, random, total);

        intent.putExtras(bundle);

        btContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
    }

    private double calcularTotal(double random) {
        if (cbMovilidadReducida.equals("true"))
            random += 50;
        if (cbPrimeraClase.equals("true"))
            random += 250;
        if (swMascota.equals("true"))
            random += 200;
        if (cbDesayuno.equals("true"))
            random +=15;
        if (cbAlmuerzo.equals("true"))
            random +=25;
        if (cbCena.equals("true"))
            random +=20;
        if (swSeguro.equals("true"))
            random +=5.5;
        if (swPreferente.equals("true"))
            random +=100;

        return random;
    }

    private Bundle pasarDatos(Bundle bundle, double random,double total) {
        bundle.putString("etOrigen", etOrigen);
        bundle.putString("etDestino", etDestino);
        bundle.putString("cbMovilidadReducida", cbMovilidadReducida);
        bundle.putString("cbPrimeraClase", cbPrimeraClase);
        bundle.putString("swMascota", swMascota);
        bundle.putString("cbDesayuno", cbDesayuno);
        bundle.putString("cbAlmuerzo", cbAlmuerzo);
        bundle.putString("cbCena", cbCena);
        bundle.putString("swSeguro", swSeguro);
        bundle.putString("swPreferente", swPreferente);
        bundle.putString("random", String.valueOf(random));
        bundle.putString("total", String.valueOf(total));

        return bundle;
    }

    private int pasarNumero(String str) {
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray())
            sb.append((int)c);

        BigInteger mInt = new BigInteger(sb.toString());
        return mInt.intValue();
    }

    private void getDatos(Bundle bundle) {
        etOrigen=bundle.getString("etOrigen");
        etDestino=bundle.getString("etDestino");
        cbMovilidadReducida=bundle.getString("cbMovilidadReducida");
        cbPrimeraClase=bundle.getString("cbPrimeraClase");
        swMascota=bundle.getString("swMascota");
        cbVentanilla=bundle.getString("cbVentanilla");
        cbDesayuno=bundle.getString("cbDesayuno");
        cbAlmuerzo=bundle.getString("cbAlmuerzo");
        cbCena=bundle.getString("cbCena");
        swSeguro=bundle.getString("swSeguro");
        swPreferente=bundle.getString("swPreferente");
    }
}