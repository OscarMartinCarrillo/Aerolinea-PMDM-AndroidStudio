package org.izv.omc.aerolinealoremipsum_pmdm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {
    protected String etOrigen, etDestino, cbMovilidadReducida, cbPrimeraClase, swMascota, cbVentanilla, cbDesayuno, cbAlmuerzo, cbCena, swSeguro, swPreferente, random, total;
    protected TextView tvPrecioVuelo, tvPrecioMovilidadReducida, tvPrecioPrimeraClase, tvPrecioMascota, tvPrecioVentanilla, tvPrecioDesayuno, tvPrecioAlmuerzo, tvPrecioCena, tvPrecioSeguro, tvPrecioPreferente, tvPrecioTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Bundle bundle = getIntent().getExtras();

        getDatos(bundle);

        initialize();

    }

    private void initialize() {
        editTexts();
        imprimirDatos();

    }

    private void editTexts() {
        tvPrecioVuelo=findViewById(R.id.tvPrecioVuelo);
        tvPrecioMovilidadReducida=findViewById(R.id.tvPrecioMovilidadReducida);
        tvPrecioPrimeraClase=findViewById(R.id.tvPrecioPrimeraClase);
        tvPrecioMascota=findViewById(R.id.tvPrecioMascota);
        tvPrecioVentanilla=findViewById(R.id.tvPrecioVentanilla);
        tvPrecioDesayuno=findViewById(R.id.tvPrecioDesayuno);
        tvPrecioAlmuerzo=findViewById(R.id.tvPrecioAlmuerzo);
        tvPrecioCena=findViewById(R.id.tvPrecioCena);
        tvPrecioSeguro=findViewById(R.id.tvPrecioSeguro);
        tvPrecioPreferente=findViewById(R.id.tvPrecioPreferente);
        tvPrecioTotal=findViewById(R.id.tvPrecioTotal);

    }

    private void imprimirDatos() {
        tvPrecioVuelo.setText(random);
        if (cbMovilidadReducida.equals("true"))
            tvPrecioMovilidadReducida.setText("50");
        if (cbPrimeraClase.equals("true"))
            tvPrecioPrimeraClase.setText("250");
        if (swMascota.equals("true"))
            tvPrecioMascota.setText("200");
        if (cbDesayuno.equals("true"))
            tvPrecioDesayuno.setText("15");
        if (cbAlmuerzo.equals("true"))
            tvPrecioAlmuerzo.setText("25");
        if (cbCena.equals("true"))
            tvPrecioCena.setText("20");
        if (swSeguro.equals("true"))
            tvPrecioSeguro.setText("5.5");
        if (swPreferente.equals("true"))
            tvPrecioPreferente.setText("100");

        tvPrecioTotal.setText(total);
    }

    private void getDatos(Bundle bundle) {
        etOrigen=bundle.getString("etOrigen");
        etDestino=bundle.getString("etDestino");
        cbMovilidadReducida=bundle.getString("cbMovilidadReducida");
        cbPrimeraClase=bundle.getString("cbPrimeraClase");
        swMascota=bundle.getString("swMascota");
        cbVentanilla=bundle.getString("cbVentanilla");
        cbDesayuno=bundle.getString("cbDesayuno");
        cbAlmuerzo=bundle.getString("cbAlmuerzo");
        cbCena=bundle.getString("cbCena");
        swSeguro=bundle.getString("swSeguro");
        swPreferente=bundle.getString("swPreferente");
        random = bundle.getString("random");
        total = bundle.getString("total");
    }
}